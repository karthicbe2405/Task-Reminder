import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthComponent } from './auth/auth.component';
import { AuthGuard } from './auth/auth.guard';
import { TaskDetailComponent } from './tasks/task-detail/task-detail.component';
import { TaskListComponent } from './tasks/task-list/task-list.component';
import { TasksComponent } from './tasks/tasks.component';

const routes: Routes = [
  {path:'',redirectTo: '/tasks', pathMatch: 'full'},
  {path:'auth',component:AuthComponent},
  {path:'tasks',component:TasksComponent, canActivate : [AuthGuard],
  children : [
    // {path:'',component:TaskListComponent},
    {path:'new/task',component:TaskDetailComponent},
    {path:':id/task',component:TaskDetailComponent}
  ]
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
