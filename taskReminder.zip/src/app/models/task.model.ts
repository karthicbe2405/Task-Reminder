export class Task{
    title: string;
    description: string;
    reminderTime: string;
    createdBy: string;
    assignedTo: string;
}